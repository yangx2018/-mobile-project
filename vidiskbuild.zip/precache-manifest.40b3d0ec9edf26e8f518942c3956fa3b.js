self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "228b42bb48fbfa36353d66231dbc049c",
    "url": "/vidisk-h5/index.html"
  },
  {
    "revision": "aca4174a5b911902992a",
    "url": "/vidisk-h5/static/css/2.4c34b942.chunk.css"
  },
  {
    "revision": "edb1be3b1444cd26de34",
    "url": "/vidisk-h5/static/css/main.ec1c206b.chunk.css"
  },
  {
    "revision": "aca4174a5b911902992a",
    "url": "/vidisk-h5/static/js/2.88911303.chunk.js"
  },
  {
    "revision": "4d47ffde3dc69784e8e23fd910817ef8",
    "url": "/vidisk-h5/static/js/2.88911303.chunk.js.LICENSE.txt"
  },
  {
    "revision": "edb1be3b1444cd26de34",
    "url": "/vidisk-h5/static/js/main.3c174b61.chunk.js"
  },
  {
    "revision": "a579b1fa28f3db2c0bc6",
    "url": "/vidisk-h5/static/js/runtime-main.fa1322d0.js"
  },
  {
    "revision": "d0b92cc3d0d5104e5948acdb70477e36",
    "url": "/vidisk-h5/static/media/empty.a5c21ec5.jpg"
  }
]);