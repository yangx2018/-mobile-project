import scan from './scan.png';
import plus from './plus.png';
import user from './user.png';
import pwd from './password.png';
import filepack from './filepack.png';
import plusBlack from './plusBlack.png';
export default{
    scan,
    plus,
    plusBlack,
    user,
    pwd,
    filepack
}