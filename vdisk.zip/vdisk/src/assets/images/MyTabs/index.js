import home from './home.png';
import homeA from './homeA.png';
import user from './user.png';
import userA from './userA.png'
export default{
    home, 
    homeA,
    user,
    userA
}